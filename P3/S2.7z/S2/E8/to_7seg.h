#ifndef TO_7SEG_H
# define TO_7SEG_H
# include "mbed.h" 

int8_t to_7seg(uint8_t code);

#endif // TO_7SEG_